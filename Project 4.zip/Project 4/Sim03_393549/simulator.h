#ifndef SIMULATOR_H
#define SIMULATOR_H

// define libraries
#include "configops.h"
#include "metadataops.h"
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "simtimer.h"
#include <pthread.h>


// pcb struct definition
typedef struct PCBType
   {
   int processID;
   
   // process state
   ProcessState state;
   
   // time remaining (all processes codes * config data)
   int timeRemaining;
   
   // start of the pcb's process
   struct OpCodeType *processStart;
   
   // ranges for low memory
   int lowMemoryRange[ MAX_STR_LEN ];
   
   // ranges for high memory
   int highMemoryRange[ MAX_STR_LEN ];
   
   // how much low memory is used
   int lowMemoryUsed;
      
   // how much high memory used
   int highMemoryUsed;
   
   // is the memory valid
   bool memoryValid;
   
   // next node
   struct PCBType *nextNode;
   
   } PCBType;

// Function declarations

// function name: runSim
// process: runs the simulator by creating Process control blocks
// ran alongside the meta data linked list
// input: config master pointer, meta master pointer
// output: depending on log to code, either ouputs
// simulator operations to file, monitor or both
// dependencies: accessTimer, sprintf, metaToPcb, compareString
// setAllProcessStates, checkForExitStates, setProcessState, startEndProcess
// clearPCBDataList, free
void runSim( ConfigDataType *configPtr, OpCodeType *metaPtr );

// function name: getSchedule
// process: finds the next schedule based on config
int *getSchedule( PCBType *PCBDataPtr, ConfigDataCodes schedCode, int *schedArray, int numProcesses );

// function name: findNextProcess
// process: finds the next available process in order
PCBType *findNextProcess( PCBType *PCBDataPtr, int currentProcessID );

// function name: bubbleSort
// process: sorts the array with the bubble sort algorithm ( for scheduling )
void bubbleSort( int *schedArray, int *timeArray, int arraySize );

// function name: isInArray
// process: finds value in array
bool isInArray( int *array, int size, int searchVal );

// function name: checkInMemory
// process: checks if memory high and low are available
bool checkInMemory( PCBType *PCBDataPtr, int lowMemoryLimit, int highMemoryLimit );

// function name: clearPCBDataList
// process: Recursively traverses the pcb linked list and frees each node
// input: current node of the list
// output: cleared memory for PCB linked list
// dependencies: clearPCBDataList
PCBType *clearPCBDataList( PCBType *localPtr );

// function name: metaToPcb
// process: Creates proper amount of PCB for each process
// input: meta data pointer (head), PCB head pointer, config pointer
// output: created each PCB for each process
// dependencies: compareString
void metaToPcb( OpCodeType *metaPtr, PCBType **PCBDataHead, ConfigDataType *configPtr );

// function name: getTimeRemaining
// process: go through intArg1, check for dev or cpu and multiply
// accordingly for each app start
// input: meta data pointer, config pointer
// output: time remaning (in ms)
// dependencies: NONE
int getTimeRemaining( OpCodeType *metaPtr, ConfigDataType *configPtr );

// function name: outputResults
// process: output simulator results to either monitor or file
// or both
// input: config pointer, ouput string
// output: simulation process to desired location
// dependencies: printf, outputToFile
void outputResults( ConfigDataType *configMasterPtr, char *outputStr );

// function name: setProcessState
// process: set initial/or changes the process state of the PCB based on code
// input: Pcb data pointer, process code
// output: changed process state
// dependencies: NONE
void setProcessState( PCBType *PCBDataPtr, ProcessState code );

// function name: setALlProcessState
// process: set initial/or changes the process state of the PCB
// input: 
// output: 
// dependencies: setProcessState
void setAllProcessStates( PCBType *PCBHeadPtr, ProcessState code );

// function name: checkForExitStates
// process: checks all processes to see if there is once without EXIT state
// input: pcb data pointer
// output: boolean test if there are any EXIT states 
// dependencies: NONE
bool checkForExitStates( PCBType *PCBDataPtr );

// function name: checkEndOfProcess
// process: checks if the command and firstARG is app end
// input: meta data pointer
// output: boolean test of meta data pointer 'app' 'end'
// dependencies: compareString
bool checkEndOfProcess( OpCodeType *metaDataPtr );

// function name: startEndProcess
// process: starts or ends a process
// input: meta data pointer, process number, out string, start end op code
// output: initiating the start or end of a process
// dependencies: compareString, sprintf
void startEndProcess( OpCodeType *metaDataPtr, int processNumber,
                                       char *outStr, int startEndOpCode, int memoryAvailable, int *memoryUsed, PCBType *PCBDataPtr, bool memoryDisplay  );

// function name: outputToFile
// process: takes in output string and filename and puts in log to file
// input: output and log to file destination
// output: process information
// dependencies: openOutputFile, writeStringToFile, closeOutputFile
void outputToFile( char *outString, const char *filename );

// function declaration for leveringtons code

/*
Name: accessOutputFilePointer
process: allows setting or accessing file pointer;
		 note: pointer is maintained (static) value initialized to NULL
Function input/parameters: control code (int), file pointer (FILE *)
						   DUMMY_OUTPUT_FILE_PTR used 
						   if not setting file pointer
Function output/parameters: none
Function output/returned: file pointer (FILE *)
Device input/file: none
Device output/monitor: none
Dependencies: none
*/
FILE *accessOutputFilePointer( int ctrlCode, const FILE *filePtr );

/*
Name: closeOutputFile
Process: closes output file, returns true if successful, false otherwise
Function input/parameters: none
Function output/parameters: none
Function output/returned: operation success (bool)
Device input/file: none
Device output/file: output file closed
Dependencies: accessOutputFilePointer, fclose
*/
bool closeOutputFile();

/*
Name: openOutputFile
Process: opens input file, returns true if successful, false otherwise
Function input/parameters: file name (c-string)
Function output/parameters: none
Function output/returned: operation success (bool)
Device input/file: none
Device output/file: output file opened
Dependencies: accessOutputFilePointer, fopen
*/
bool openOutputFile( const char *fileName );

/*
Name: writeCharacterToFile
Process: writes individual character to file,
		 returns true if successful, false otherwise
Function input/parameters: character to output (char)
Function output/parameters: none
Function output/returned: operation success (bool)
Device input/file: none
Device output/file: character written to file
Dependencies: accessOutputFilePointer, fprintf
*/
bool writeCharacterToFile( char outChar );

/*
Name: writeCharactersToFile
Process: writes multiple characters to file,
		 returns true if successful, false otherwise
Function input/parameters: number of characters to output (int),
						   character to output (char)
Function output/parameters: none
Function output/returned: operation success (bool)
Device input/file: none
Device output/file: multiple characters written to file
Dependencies: writeCharacterToFile
*/
bool writeCharactersToFile( int numChars, char outChar );

/*
Name: writeStringToFile
Process: writes String value to file,
		 returns true if successful, false otherwise
Function input/parameters: double value to output (double),
						 number of digits to right of radix point
						 (precision) (int)
Function output/parameters: none
Function output/returned: operation success (bool)
Device input/file: none
Device output/file: String written to file
Dependencies: writeStringJustifiedToFile
*/
bool writeStringToFile( const char *outString );

/*
Name: writeStringJustifiedToFile
Process: write string to file within specified block size
		 and with specified justification
Function input/parameters:
			   outVal - the string value to be output
			   blockSize - the width of the block within which
						   to print the integer value (int)
			   justify - "LEFT," "RIGHT," or "CENTER" justification 
						 in block (c-string)
Function output/parameters: None
Function output/returned: success of output operation (bool)
Function input/keyboard: None
Device output/file: string written to file as specified
Dependencies: strlen, strcmp, writeCharactersToFile, fprint
*/
bool writeStringJustifiedToFile( const char *outStr,
										int blockSize, const char *justify );



#endif  