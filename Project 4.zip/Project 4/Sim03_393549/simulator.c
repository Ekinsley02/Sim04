#include "simulator.h"


// function name: runSim
// process: runs the simulator by creating Process control blocks
// ran alongside the meta data linked list
// input: config master pointer, meta master pointer
// output: depending on log to code, either ouputs
// simulator operations to file, monitor or both
// dependencies: accessTimer, sprintf, metaToPcb, compareString
// setAllProcessStates, checkForExitStates, setProcessState, startEndProcess
// clearPCBDataList, free
void runSim( ConfigDataType *configMasterPtr, OpCodeType *metaMasterPtr )
   {    
   
   // initialize functions/variables
   
      // initilaize pcb struct
      PCBType *PCBDataPtr = NULL;
      
      // initialize temporary pcb for traversal
      PCBType *tempPCB = NULL;
      
      // this will always be the top if list, do not change
      PCBType *PCBHeadPtr = NULL;
      
      // initialize time variable
      char timeStr[ MIN_STR_LEN ];
      
      // initialize time variable
      char *processStr = NULL;
      
      // initialize output string for display
      char *outputStr = NULL;
      
      // initialize timing thread
      int ioTime;
      
      // scheduling order array
      int *schedule = NULL;
      
      // order index
      int orderIndex = 0;
      
      int numProcesses = 0, memoryUsed = 0;
      
      bool memoryDisplay;
   
   // final output string
   outputStr = ( char * )malloc( MAX_INT * sizeof( char ) );
   
   // current proccess string
   processStr = ( char * )malloc( MAX_INT * sizeof( char ) );
   
   // boolean for memory output
   memoryDisplay = configMasterPtr->memDisplay;
   
   // set time variable ZERO
      // setTimer
   accessTimer( ZERO_TIMER, timeStr );
   
   // ensure outputStr starts empty
   outputStr[ 0 ] = '\0';
   
   // display simulator run title
   sprintf( outputStr + getStringLength( outputStr ), "Simulator Run" );
   sprintf( outputStr + getStringLength( outputStr ), "\n-------------\n" );
   
   // initialize meta data into pcb
      // function: metaToPcb
   metaToPcb( metaMasterPtr, &PCBDataPtr, configMasterPtr );
   
   // check for system start
   if( compareString( metaMasterPtr->command, "sys" ) == STR_EQ &&
       compareString( metaMasterPtr->strArg1, "start" ) == STR_EQ )
      {
         
      // display start of simulator
         // function: sprintf
      sprintf( outputStr + getStringLength( outputStr ),
                                       "\n  %s, OS: Simulator start", timeStr );
      
      // go to the next pointer for meta data
      metaMasterPtr = metaMasterPtr->nextNode;
      }
      
   // set all processes into ready state
      // function: setAllProcessStates
   setAllProcessStates( PCBDataPtr, READY_STATE );
   
   // make temporary PCB equal to PCB head
   tempPCB = PCBDataPtr;
     
   // lap timer for output
   accessTimer( LAP_TIMER, timeStr );
      
   // traverse through temporary PCB linked list
   while( tempPCB != NULL )
      {
      
      // display each process switching from NEW to READY
      sprintf( outputStr + getStringLength( outputStr ), 
                     "\n  %s, OS: Process %d set to READY state from NEW state",
                                                timeStr, tempPCB->processID );
      
      // find the number of processes
      numProcesses = numProcesses + 1;
      
      // increment temp PCB
      tempPCB = tempPCB->nextNode;
      }
   
   // after traversal, go back to top of list
   tempPCB = PCBDataPtr;
   
   if( memoryDisplay )
      {
      
      // output memory initialization
      sprintf( outputStr + getStringLength( outputStr ),
         "\n--------------------------------------------------\n" );
      
      sprintf( outputStr + getStringLength( outputStr ),
         "After memory initialization\n" );
      
      sprintf( outputStr + getStringLength( outputStr ),
         "0 [ Open, P#: x, 0-0 ] %d\n", configMasterPtr->memAvailable - 1 );
      
      sprintf( outputStr + getStringLength( outputStr ),
         "--------------------------------------------------" );
      }
   
   // get the schedule based on cpu sched code
   schedule = getSchedule( PCBDataPtr, configMasterPtr->cpuSchedCode, schedule, numProcesses );
   
   // this will always be the start of the linked list
      // this should not change
   PCBHeadPtr = PCBDataPtr;

   // loop until all processes are in EXIT state
      // function: checkForExitStates
   while( !checkForExitStates( PCBDataPtr ) )
      {
      
      // find the next process
      tempPCB = findNextProcess( PCBHeadPtr, schedule[ orderIndex ] );
      
      // select the next available process, and display time remaining
         // function: sprintf
      sprintf( outputStr + getStringLength( outputStr ),
                          "\n  %s, OS: Process %d selected with %d ms remaining\n",
                   timeStr, tempPCB->processID, tempPCB->timeRemaining );
      
      // set the process from READY to RUNNING
         // setProcessState
      setProcessState( PCBDataPtr, RUNNING_STATE );
      
      setProcessState( tempPCB, RUNNING_STATE );
      
      // lap timer for output
      accessTimer( LAP_TIMER, timeStr );  
      
      // check to see if sucessful set process
      if( tempPCB->state == RUNNING_STATE )
         {
         
         sprintf( outputStr + getStringLength( outputStr ),
                          "  %s, OS: Process %d set from READY to RUNNING\n\n",
                                              timeStr, tempPCB->processID );
         }
      
      // incrememnt the master pointer from sys start
      metaMasterPtr = metaMasterPtr->nextNode;
      
      // after first process
      if( PCBDataPtr->processID > 0 )
         {
         
         // skip over 'sys' 'end'
         metaMasterPtr = metaMasterPtr->nextNode;
         }
      
      // loop until end of process (app end)
         // function: checkEndOfProcess
      while( !checkEndOfProcess( tempPCB->processStart ) )
         {
        
         // timing for each process, threaded for dev
         if( compareString( tempPCB->processStart->command, "cpu" ) == STR_EQ )
            {
            
            runTimer( ( int )tempPCB->processStart->opEndTime );
            }
            
         // otherwise, check if meta command is a device
         else if( compareString( tempPCB->processStart->command, "dev" ) == STR_EQ )
            {
            
            pthread_t ioThread;
      
            ioTime = ( int )tempPCB->processStart->opEndTime;
            
            pthread_create( &ioThread, NULL, runThreadedTimer, ( void * )&ioTime );
            
            pthread_join( ioThread, NULL );
            }
            
         // lap timer for output
         accessTimer( LAP_TIMER, timeStr );

         // start current process
            // function: startEndProcess
         startEndProcess( tempPCB->processStart, tempPCB->processID,
            processStr, START, configMasterPtr->memAvailable, &memoryUsed, tempPCB, memoryDisplay );
                                                
         // output current process
         sprintf( outputStr + getStringLength( outputStr ), "  %s, %s", timeStr,
                                                                  processStr );
         
         if( !tempPCB->memoryValid )
            {
            
            // lap timer for output
            accessTimer( LAP_TIMER, timeStr );
            
            sprintf( outputStr + getStringLength( outputStr ),
               "  %s, OS: Process %d, failed mem %s request\n",
                  timeStr, tempPCB->processID, tempPCB->processStart->strArg1 );
             
            break;
            }
            
         // lap timer for output
         accessTimer( LAP_TIMER, timeStr );
         
         // end current process
            // function: startEndProcess
         startEndProcess( tempPCB->processStart, tempPCB->processID,
                                                             processStr,
            END, configMasterPtr->memAvailable, &memoryUsed, tempPCB, memoryDisplay );
            
         // output current process
         sprintf( outputStr + getStringLength( outputStr ), "  %s, %s", timeStr,
                                                                  processStr );
         
         // increment master pointer
         metaMasterPtr = metaMasterPtr->nextNode;
         
         // increment process
         tempPCB->processStart = tempPCB->processStart->nextNode;
         
         // end loop until end of process
         }
      
      // lap timer for output
      accessTimer( LAP_TIMER, timeStr );
      
      // if the memory faults, output segmentation fault
      if( !tempPCB->memoryValid )
         {
         
         sprintf( outputStr + getStringLength( outputStr ),
                   "\n  %s, OS: Segmentation fault, Process %d ended \n", timeStr, tempPCB->processID );
         }
      
      else
         {
         
         // display process end
            // sprintf
         sprintf( outputStr + getStringLength( outputStr ),
                   "\n  %s, OS: Process %d ended\n", timeStr, tempPCB->processID );
         }
      
      // output clear success
      if( memoryDisplay )
         {
         
         sprintf( outputStr + getStringLength( outputStr ),
          "--------------------------------------------------\n" );
          
         sprintf( outputStr + getStringLength( outputStr ),
          "After clear process %d successs\n", tempPCB->processID );
          
         sprintf( outputStr + getStringLength( outputStr ),
          "0 [ Open, P#: x, 0-0 ] %d\n", configMasterPtr->memAvailable - 1 );
          
         sprintf( outputStr + getStringLength( outputStr ),
          "--------------------------------------------------" );
         }
      
      // set process to EXIT state
         // function: setProcessState
      setProcessState( PCBDataPtr, EXIT_STATE );
      
      // display process set to exit
         // sprintf
      sprintf( outputStr + getStringLength( outputStr ),
          "\n  %s, OS: Process %d set to EXIT", timeStr, tempPCB->processID );
      
      // incrememnt loop counter
      PCBDataPtr = PCBDataPtr->nextNode;
      
      // increment order index
      orderIndex = orderIndex + 1;
      
      // reset memory used
      memoryUsed = 0;
      
      // end loop until end of process
      }
      
   // increment the meta master pointer to system end
   metaMasterPtr = metaMasterPtr->nextNode;
   
   // reset PCB information (avoid leaks)
   tempPCB = PCBHeadPtr;
   
   PCBDataPtr = tempPCB;
   
   PCBDataPtr = clearPCBDataList( PCBDataPtr );
   
   // check for system end, stop the system, and display
   if( compareString( metaMasterPtr->command, "sys" ) == STR_EQ &&
       compareString( metaMasterPtr->strArg1, "end" ) == STR_EQ )
      {
      
      accessTimer( LAP_TIMER, timeStr );
      
      sprintf( outputStr + getStringLength( outputStr ),
                                            "\n  %s, OS: System stop", timeStr );
      }
   
   // display allocation success
   if( memoryDisplay )
      {

      sprintf( outputStr + getStringLength( outputStr ),
       "\n--------------------------------------------------\n" );
       
      sprintf( outputStr + getStringLength( outputStr ),
       "After clear all process successs\n" );
       
      sprintf( outputStr + getStringLength( outputStr ),
       "No memory configured\n" );
       
      sprintf( outputStr + getStringLength( outputStr ),
       "--------------------------------------------------" );
      }
   
   // simulation end
   // lap timer for output
   accessTimer( LAP_TIMER, timeStr );
   
   // display simulation end
   sprintf( outputStr + getStringLength( outputStr ),
                                       "\n  %s, OS: Simulation end\n", timeStr );
   
   // stop the timer
   accessTimer( STOP_TIMER, timeStr );
   
   // output to terminal based on log to
      // function: outputResults
   outputResults( configMasterPtr, outputStr );
   
   // Free the allocated memory, avoids memory leaks
   free( outputStr );
   
   free( processStr );
   
   free( schedule );
   
   }

PCBType *findNextProcess( PCBType *PCBDataPtr, int currentProcessID )
   {
   
   // initialize functions/variables
      
      // initialize temp PCB
      PCBType *tempPCB;
   
   // point to head
   tempPCB = PCBDataPtr;
   
   // traverse PCB
   while( tempPCB != NULL )
      {
      
      // if process ID found, return
      if( tempPCB->processID == currentProcessID )
         {
         
         return tempPCB;
         }
      
      tempPCB = tempPCB->nextNode;
      }
   
   // otherwise return NULL
   return NULL;
   }

int *getSchedule( PCBType *PCBDataPtr, ConfigDataCodes schedCode, int *schedArray, int numProcesses )
   {
   
   // initialize functions/variables
      
      // temp array for schedule order
      int *timeArray;
      
      // initialize temporary PCB
      PCBType *tempPCB;
      
      int index = 0;
   
   // point to head
   tempPCB = PCBDataPtr;
   
   // allocate schedule array
   schedArray = ( int* )malloc( numProcesses * sizeof(int) );
   
   // allocate time array
   timeArray = ( int* )malloc( numProcesses * sizeof(int) );
   
   // fill the temp array in process order
   while( tempPCB != NULL )
      {
      
      schedArray[ index ] = tempPCB->processID;
      
      timeArray[ index ] = tempPCB->timeRemaining;
      
      tempPCB = tempPCB->nextNode;
      
      index++;
      }
   
   // check the schedCode
   switch( schedCode )
      {
      
      case CPU_SCHED_SJF_N_CODE:
         // bubble sort based on time remaining
         bubbleSort( schedArray, timeArray, index );
         break;
      
      default:
         break;
      }
   
   // free time array (avoid leaks)
   free( timeArray );
   
   // return array
   return schedArray;
   }
   
void bubbleSort( int *schedArray, int *timeArray, int arraySize )
   {
      
   // initialize functions/variables
      int wkgIndex;
      
      int currentIndex;
      
      int tempNum;
      
   for( wkgIndex = arraySize - 1; wkgIndex >= 0; wkgIndex-- ) 
      {
        
      for( currentIndex = 0; currentIndex < wkgIndex; currentIndex++ ) 
         {
            
         if( timeArray[ currentIndex ] > timeArray[ currentIndex + 1 ] ) 
            {
               
            // swap values for time remaining array
            tempNum = timeArray[ currentIndex ];
            
            timeArray[ currentIndex ] = timeArray[ currentIndex + 1];
            
            timeArray[ currentIndex + 1 ] = tempNum;
            
            // swap/sort the ID array as well
            tempNum = schedArray[ currentIndex ];
            
            schedArray[ currentIndex ] = schedArray[ currentIndex + 1];
            
            schedArray[ currentIndex + 1 ] = tempNum;
            }
         }
      }
   }

// function name: clearPCBDataList
// process: Recursively traverses the pcb linked list and frees each node
// input: current node of the list
// output: cleared memory for PCB linked list
// dependencies: clearPCBDataList, free
PCBType *clearPCBDataList( PCBType *localPtr )
   {
      
   // check for local pointer not set to null (list not empty)
   if( localPtr != NULL )
      {
         
      // call recursive function with next pointer
      clearPCBDataList( localPtr->nextNode );
        
      // free memory to OS
      free( localPtr );
      
      // set given pointer to NULL
      localPtr = NULL;
      }

   // return null to calling function
   return NULL;
   }

// function name: metaToPcb
// process: Creates proper amount of PCB for each process
// input: meta data pointer (head), PCB head pointer, config pointer
// output: created each PCB for each process
// dependencies: compareString
void metaToPcb( OpCodeType *metaPtr, PCBType **PCBDataHead, ConfigDataType *configPtr )
   {
   
   // initilaize functions/variables
   
      // initialize the amount of processes
      int processAmount = 0;                                             
      
      // initialize new node pointer
      PCBType *newNodePtr = NULL;
      
      // initialize current node pointer
      PCBType *currentNodePtr = NULL;
      
      OpCodeType *localMetaPtr = metaPtr;
      
      int index = 0;
   
   // traverse through the meta data linked list
   while( localMetaPtr != NULL )
      {
      
      // check for app start
      if( compareString( localMetaPtr->command, "app" ) == STR_EQ &&
          compareString( localMetaPtr->strArg1, "start" ) == STR_EQ )
         {
         
         // allocate memory for the new PCB node
         newNodePtr = ( PCBType * )malloc( sizeof( PCBType ) );

         // fill the node
         newNodePtr->timeRemaining = getTimeRemaining( localMetaPtr, configPtr );
         newNodePtr->processID = processAmount;
         newNodePtr->nextNode = NULL;
         newNodePtr->state = NEW_STATE;
         newNodePtr->processStart = localMetaPtr->nextNode;
         newNodePtr->lowMemoryUsed = configPtr->memAvailable;
         newNodePtr->highMemoryUsed = 0;
         newNodePtr->memoryValid = true;
         
         for( index = 0; index < MAX_STR_LEN; index++ )
            {
            
            newNodePtr->lowMemoryRange[ index ] = -1;
            newNodePtr->highMemoryRange[ index ] = -1;
            }

         // check if the list is empty
         if( *PCBDataHead == NULL )
            {
               
            // make the new node the head
            *PCBDataHead = newNodePtr;
            }
         
         // otherwise there is at least one PCB
         else
            {
               
            // Traverse the list to find the last node
            currentNodePtr = *PCBDataHead;
            while( currentNodePtr->nextNode != NULL )
               {
                  
               currentNodePtr = currentNodePtr->nextNode;
               }

            // Link the new node to the end of the list
            currentNodePtr->nextNode = newNodePtr;
            }

         // increment process count
         processAmount++;
        }

      // move to the next meta data node
      localMetaPtr = localMetaPtr->nextNode;
      }
   }

// function name: getTimeRemaining
// process: go through intArg1, check for dev or cpu and multiply
// accordingly for each app start
// input: meta data pointer, config pointer
// output: time remaning (in ms)
// dependencies: NONE
int getTimeRemaining( OpCodeType *metaPtr, ConfigDataType *configPtr )
   {
   
   // initialize functions/variables
   
      // initialize timeRemaining tracker
      int timeRemaining = 0;
      
      double timeProcessTook = 0;
      
      OpCodeType *localMetaPtr = metaPtr;
      
   // traverse through meta data until app end
   while( !checkEndOfProcess( localMetaPtr ) )
      {
         
      // check if the current meta data node is cpu process
      if( compareString( localMetaPtr->command, "cpu" ) == STR_EQ )
         {
            
         // multiply current nodes pid with cpu cycle rate
            // and add to time remaining
         timeRemaining = timeRemaining + 
                               ( configPtr->procCycleRate * localMetaPtr->intArg2 );
         
         // calculate the individual process time process took
         timeProcessTook = configPtr->procCycleRate * localMetaPtr->intArg2;
         
         // add individual process time to opEndTime
         localMetaPtr->opEndTime = timeProcessTook;
         }
            
      // check if the current meta data node is io process
      if( compareString( localMetaPtr->command, "dev" ) == STR_EQ )
         {
            
         // multiply current nodes pid with io cycle rate
            // and add to time remaining
         timeRemaining = timeRemaining + 
                                 ( configPtr->ioCycleRate * localMetaPtr->intArg2 );
         
         // calculate the individual process time process took
         timeProcessTook = configPtr->ioCycleRate * localMetaPtr->intArg2;
         
         // add individual process time to opEndTime
         localMetaPtr->opEndTime = timeProcessTook;
         }
      
      // increment meta pointer
      localMetaPtr = localMetaPtr->nextNode;
      
      // end of traversal
      }
   
   // return timeRemaining ( total process block time in ms )
   return timeRemaining;
   }

// function name: outputResults
// process: output simulator results to either monitor or file
// or both
// input: config pointer, ouput string
// output: simulation process to desired location
// dependencies: printf, outputToFile
void outputResults( ConfigDataType *configPtr, char *outputStr )
   {
   
   // check the log to code for monitor or both
   if( configPtr->logToCode == LOGTO_MONITOR_CODE ||
                                      configPtr->logToCode == LOGTO_BOTH_CODE )
      {
         
      // print the results to terminal
      printf( "%s", outputStr );
      }
   
   // check the log to code for file or both
   if( configPtr->logToCode == LOGTO_FILE_CODE ||
                                      configPtr->logToCode == LOGTO_BOTH_CODE )
      {
         
      // output results to file
         // function: outputToFile
      outputToFile( outputStr, configPtr->logToFileName );
      }
   }

// function name: setProcessState
// process: set initial/or changes the process state of the PCB based on code
// input: Pcb data pointer, process code
// output: changed process state
// dependencies: NONE
void setProcessState( PCBType *PCBDataPtr, ProcessState code )
   {
   
   switch( code )
      {
         
      // check if the code is NEW state
      case NEW_STATE:
         
         // set the PCB current node to NEW state
         PCBDataPtr->state = NEW_STATE;
         break;
   
      // check if the code is in READY state
      case READY_STATE:
      
         // set the PCB current node to READY state
         PCBDataPtr->state = READY_STATE;
         break;
   
      // check if the code is in RUNNING state
      case RUNNING_STATE:
      
         // set the PCB current node to RUNNING state
         PCBDataPtr->state = RUNNING_STATE;
         break;
         
      // check if the code is in BLOCKED state
      case BLOCKED_STATE:
      
         // set the PCB current node to BLOCKED state
         PCBDataPtr->state = BLOCKED_STATE;
         break;
         
      // check if the code is in EXIT state
      case EXIT_STATE:
      
         // set the PCB current node to EXIT state
         PCBDataPtr->state = EXIT_STATE;
         break;
      }
   }

// function name: setALlProcessState
// process: set initial/or changes the process state of all PCB's
// input: pcb head pointer, process code
// output: 
// dependencies: setProcessState
void setAllProcessStates( PCBType *PCBHeadPtr, ProcessState code )
   {
   
   // traverse through pcb linked list starting at the beginning
   while( PCBHeadPtr != NULL )
      {
         
      // set each node to the given process
         // function: setProcessState
      setProcessState( PCBHeadPtr, code );
      
      // increment the node
      PCBHeadPtr = PCBHeadPtr->nextNode;
      
      // end of traversal
      }
   }

// function name: checkForExitStates
// process: checks all processes to see if there is once without EXIT state
// input: pcb data pointer
// output: boolean test if there are any EXIT states 
// dependencies: NONE
bool checkForExitStates( PCBType *PCBDataPtr )
   {
   
   // initialize functions/variables
      
      PCBType *tempPCB;
      
   tempPCB = PCBDataPtr;
   
   // traverse through pcb linked list starting at the beggining
   while( tempPCB != NULL )
      {
         
      // check each pcb nodes process state and see if its not EXIT
      if( tempPCB->state != EXIT_STATE )
         {
       
         // return false
         return false;
         }
      
      // go to the next node
      tempPCB = tempPCB->nextNode;
      
      // end of traversal
      }
   
   // if fallen through, all must be EXIT, return true
   return true;
   }

// function name: checkEndOfProcess
// process: checks if the command and firstARG is app end
// input: meta data pointer
// output: boolean test of meta data pointer 'app' 'end'
// dependencies: compareString
bool checkEndOfProcess( OpCodeType *metaDataPtr )
   {
   
   // check if current meta data pointer command is app and firsStrArg is end
   if( compareString( metaDataPtr->command, "app" ) == STR_EQ &&
                       compareString( metaDataPtr->strArg1, "end" ) == STR_EQ )
      {
      
      // return true 
      return true;
      }
      
   // otherwise, not at the end of process, return false
   return false;
   }

// function name: startEndProcess
// process: starts or ends a process
// input: meta data pointer, process number, out string, start end op code
// output: initiating the start or end of a process
// dependencies: compareString, sprintf
void startEndProcess( OpCodeType *metaDataPtr, int processNumber,
                                       char *outStr, int startEndOpCode, int memoryAvailable, int *memoryUsed, PCBType *PCBDataPtr, bool memoryDisplay  )
   {
   
   // initilaize functions/variables
   
      // initialize start or end string
      char *processStartStr = NULL;
      
      int memoryLow, memoryHigh;
      
      int memoryRange;
      
      int index = 0;
   
   // check to see if starting process
   if( startEndOpCode == START )
      {
     
      processStartStr = "start";
      }

   // check to see if ending process
   else if( startEndOpCode == END )
      {
         
      processStartStr = "end";
      }

   // check if meta command is cpu
   if( compareString( metaDataPtr->command, "cpu" ) == STR_EQ )
      {
      
      // start cpu process
      sprintf( outStr, "Process: %d, cpu process operation %s\n",
                                              processNumber, processStartStr );
      }
       
   // otherwise, check if meta command is a device
   else if( compareString( metaDataPtr->command, "dev" ) == STR_EQ )
      {
      
      // check if device in
      if( compareString( metaDataPtr->inOutArg, "in" ) == STR_EQ )
         {
         
         // start input operation
         sprintf( outStr, "Process: %d, %s input operation %s\n",
                        processNumber, metaDataPtr->strArg1, processStartStr );
         }
      
      // otherwise, check if device out
      else if( compareString( metaDataPtr->inOutArg, "out" ) == STR_EQ )
         {
         
         // start ouput operation
         sprintf( outStr, "Process: %d, %s output operation %s\n",
                        processNumber, metaDataPtr->strArg1, processStartStr );
         }
      }
   
   // otherwise, check if meta command is a device
   else if( compareString( metaDataPtr->command, "mem" ) == STR_EQ )
      {
         
      memoryLow = metaDataPtr->intArg2;
      memoryHigh = memoryLow + metaDataPtr->intArg3;
      memoryRange = memoryHigh - memoryLow;
 
      // check for allocate
      if( compareString( metaDataPtr->strArg1, "allocate" ) == STR_EQ && startEndOpCode == START )
         {
         
         // allocate request output
         sprintf( outStr, "Process: %d, memory allocate request ( %d, %d )\n",
               processNumber, metaDataPtr->intArg2, metaDataPtr->intArg3 );
         
         // check if valid memory location
         if( memoryLow > 0 && memoryHigh < memoryAvailable
               && ( !isInArray( PCBDataPtr->lowMemoryRange, MAX_STR_LEN, memoryLow ) )
               && ( !isInArray( PCBDataPtr->highMemoryRange, MAX_STR_LEN, memoryHigh ) ) ) 
            {
            
            // find the next index in low and high memory range
            while( index < MAX_STR_LEN && ( PCBDataPtr->lowMemoryRange[ index ] != -1 )
                                       && ( PCBDataPtr->highMemoryRange[ index ] != -1 ) )
               {
          
               index++;
               }
            
            // test if memory needs to be updated      
            if( memoryLow < PCBDataPtr->lowMemoryUsed )
               {
               
               PCBDataPtr->lowMemoryUsed = metaDataPtr->intArg2;
               }
            
            if( memoryHigh > PCBDataPtr->highMemoryUsed )
               {
               
               PCBDataPtr->highMemoryUsed = memoryHigh;
               }
            
            // fill the PCB's memory low and high
            PCBDataPtr->lowMemoryRange[ index ] = memoryLow;
            PCBDataPtr->highMemoryRange[ index ] = memoryHigh;
            
            *memoryUsed = *memoryUsed + memoryRange - 1;
            
            // display success
            if( memoryDisplay )
               {
                  
               sprintf( outStr + getStringLength( outStr ), 
                        "--------------------------------------------------\n" );
               
               sprintf( outStr + getStringLength( outStr ), 
                         "After allocate success\n" );
                         
               sprintf( outStr + getStringLength( outStr ), 
                         "0 [ Used, P#: %d, %d-%d ] %d\n" , processNumber, memoryLow, memoryHigh - 1, *memoryUsed );
                         
               sprintf( outStr + getStringLength( outStr ), 
                         "%d [ Open, P#: x, 0-0 ] %d\n" , *memoryUsed + 1, memoryAvailable - 1 );
               sprintf( outStr + getStringLength( outStr ), 
                        "--------------------------------------------------\n" );
               }
            }
            
         // otherwise display overlap failure
         else if( memoryDisplay )
            {
                  
            sprintf( outStr + getStringLength( outStr ), 
                     "--------------------------------------------------\n" );
                        
            sprintf( outStr + getStringLength( outStr ), 
                      "After allocate overlap failure\n" );
                         
            sprintf( outStr + getStringLength( outStr ), 
                     "0, [ Used, P#: %d, %d-%d ] %d\n", processNumber, memoryLow, memoryHigh - 1, *memoryUsed );
                        
            sprintf( outStr + getStringLength( outStr ), 
                        "%d, [ Open, P#: x, 0-0 ] %d\n", *memoryUsed + 1, memoryAvailable - 1 );
                        
            sprintf( outStr + getStringLength( outStr ), 
                     "--------------------------------------------------\n" );
            PCBDataPtr->memoryValid = false;
            }
         }
      
      // report success
      else if( startEndOpCode == END && PCBDataPtr->memoryValid )
         {
         
         sprintf( outStr, "Process: %d, successful mem allocate request\n",
               processNumber );
         }
         
      else if( compareString( metaDataPtr->strArg1, "access" ) == STR_EQ && startEndOpCode == START )
         {
         
         sprintf( outStr, "Process: %d, memory access request ( %d, %d )\n",
               processNumber, metaDataPtr->intArg2, metaDataPtr->intArg3 );
         
         if( checkInMemory( PCBDataPtr, memoryLow, memoryHigh ) )
            {
               
            if( memoryDisplay )
               {
                  
               sprintf( outStr + getStringLength( outStr ), 
                           "--------------------------------------------------\n" );
                           
               sprintf( outStr + getStringLength( outStr ), 
                            "After access success\n" );
                            
               sprintf( outStr + getStringLength( outStr ), 
               "0, [ Used, P#: %d, %d-%d ] %d\n", processNumber, PCBDataPtr->lowMemoryUsed, PCBDataPtr->highMemoryUsed - 1, *memoryUsed );
               
               sprintf( outStr + getStringLength( outStr ), 
               "%d, [ Open, P#: x, 0-0 ] %d\n", *memoryUsed + 1, memoryAvailable - 1 );
                           
               sprintf( outStr + getStringLength( outStr ), 
                           "--------------------------------------------------\n" );
               }
            }
         
         else if( memoryDisplay && startEndOpCode == START )
            {
            
            sprintf( outStr + getStringLength( outStr ), 
                     "--------------------------------------------------\n" );
                        
            sprintf( outStr + getStringLength( outStr ), 
                      "After access failure\n" );
                         
            sprintf( outStr + getStringLength( outStr ), 
                     "0, [ Used, P#: %d, %d-%d ] %d\n", processNumber, PCBDataPtr->lowMemoryUsed, PCBDataPtr->highMemoryUsed - 1, *memoryUsed );
                        
            sprintf( outStr + getStringLength( outStr ), 
                        "%d, [ Open, P#: x, 0-0 ] %d\n", *memoryUsed + 1, memoryAvailable - 1 );
                        
            sprintf( outStr + getStringLength( outStr ), 
                     "--------------------------------------------------\n" );
            PCBDataPtr->memoryValid = false;
            }
         }
      }
   }
bool checkInMemory( PCBType *PCBDataPtr, int lowMemoryLimit, int highMemoryLimit )
   {
   
   // initialize functions/variables
      
      int index;
   
   // traverse through both memory struct members
   for( index = 0; index < MAX_STR_LEN; index++ )
      {
      
      // check to see if the memory is available
      if( lowMemoryLimit >= PCBDataPtr->lowMemoryRange[ index ] &&
            highMemoryLimit <= PCBDataPtr->highMemoryRange[ index ] ) 
         {
         
         return true;
         }
      }
   
   // otherwise return false
   return false;
   }

bool isInArray( int *array, int size, int searchVal )
   {
   
   // initialize functions/variables
      
      int index;
   
   for( index = 0; index < size; index++ )
      {
      
      if( array[ index ] == searchVal )
         {
         
         return true;
         }
      }
   
   return false;
   }

// function name: outputToFile
// process: takes in output string and filename and puts in log to file
// input: output and log to file destination
// output: process information
// dependencies: openOutputFile, writeStringToFile, closeOutputFile
void outputToFile( char *outString, const char *filename )
   {
      
   // open file 
      // function: openOutputFile
   if( openOutputFile( filename ) )
      {
         
      // write string to file
         // function: writeStringToFile
      writeStringToFile( outString );
         
      // close file
         // function: closeOutputFile
      closeOutputFile( filename );
      } 
   }

/*
FOR OUTPUT FUNCTIONS

Formatted file ouput utility, function implementations

Copyright (c) 2021 by Michael E. Leverington

Code is free for use in whole or in part and may be modified for other
non-commercial use as long as the above copyright statement is included.
*/

// local global constants, used only in this file

// dummy file pointer for accessInputFilePointer
const FILE *DUMMY_OUTPUT_FILE_PTR = NULL;

// dummy Boolean for accessEndOfInputFileFlag, accessOpenFlag
//    const char DUMMY_OUTPUT_FLAG = false;

// control code for accessing file pointer, accessInputFilePointer
const int GET_OUTPUT_FILE_PTR = 6006;

// control code for accessing flag value, 
//   accessEndOfInputFileFlag, accessOpenFlag
const int GET_OUTPUT_FLAG = 9009;

// control code for setting file pointer, accessInputFilePointer
const int SET_OUTPUT_FILE_PTR = 8008;

/*
Name: accessOutputFilePointer
process: allows setting or accessing file pointer;
		 note: pointer is maintained (static) value initialized to NULL
Function input/parameters: control code (int), file pointer (FILE *)
						   DUMMY_OUTPUT_FILE_PTR used 
						   if not setting file pointer
Function output/parameters: none
Function output/returned: file pointer (FILE *)
Device input/file: none
Device output/monitor: none
Dependencies: none
*/
FILE *accessOutputFilePointer( int ctrlCode, const FILE *filePtr )
   {
	static FILE *filePointer = NULL;

	// check for set new pointer
	if( ctrlCode == SET_OUTPUT_FILE_PTR )
	   {
		// set file pointer to parameter
		filePointer = (FILE *)filePtr;
	   }

	// return file pointer
	return filePointer;
   }

/*
Name: closeOutputFile
Process: closes output file, returns true if successful, false otherwise
Function input/parameters: none
Function output/parameters: none
Function output/returned: operation success (bool)
Device input/file: none
Device output/file: output file closed
Dependencies: accessOutputFilePointer, fclose
*/
bool closeOutputFile()
   {
	// set local file pointer to working file pointer
	   // function: accessOutputFilePointer
	FILE *filePtr = accessOutputFilePointer( GET_OUTPUT_FILE_PTR, 
													 DUMMY_OUTPUT_FILE_PTR );

	// check for valid file pointer
	if( filePtr != NULL )
	   {
		// add two more endlines to verify that the data is ended
		// and has at least one extra newline after the data
		   // function: fprintf
		fprintf( filePtr, "\n\n" );

		// flush all data to the device
		   // function: fflush
		fflush( filePtr );

		// close file
		   // function: fclose
		fclose( filePtr );

		// set pointer to NULL
		   // function: accessOutputFilePointer
		accessOutputFilePointer( SET_OUTPUT_FILE_PTR, NULL );

		// return successful operation
		return true;
	   }  

	// return failed operation
	return false;
   }
   
/*
Name: openOutputFile
Process: opens input file, returns true if successful, false otherwise
Function input/parameters: file name (c-string)
Function output/parameters: none
Function output/returned: operation success (bool)
Device input/file: none
Device output/file: output file opened
Dependencies: accessOutputFilePointer, fopen
*/
bool openOutputFile( const char *fileName )
   {
	// initialize variables
	FILE *filePtr = accessOutputFilePointer( GET_OUTPUT_FILE_PTR, 
													DUMMY_OUTPUT_FILE_PTR );
	char writeCharacter[] = "w";

	// check for file not open
	if( filePtr == NULL )
	   {
		// open file
		   // function: fopen
		filePtr = fopen( fileName, writeCharacter );

		// check for success of file open
		if( filePtr != NULL )
		   {
			// set pointer in access function
			   // function: accessInputFilePointer
			accessOutputFilePointer( SET_OUTPUT_FILE_PTR, filePtr );

			// return operation success
			return true;
		   }
	   }
	// end of file not previously opened block

	// return operation failure
	return false;
   }

/*
Name: writeCharacterToFile
Process: writes individual character to file,
		 returns true if successful, false otherwise
Function input/parameters: character to output (char)
Function output/parameters: none
Function output/returned: operation success (bool)
Device input/file: none
Device output/file: character written to file
Dependencies: accessOutputFilePointer, fprintf
*/
bool writeCharacterToFile( char outChar )
   {
	// initialize variables, set file pointer
	   // function: accessOutputFilePointer
	FILE *filePtr = accessOutputFilePointer( GET_OUTPUT_FILE_PTR, 
													DUMMY_OUTPUT_FILE_PTR );

	// check for open file
	   // function: checkForOutputFileOpen
	if( filePtr != NULL )
	   {
		// write character
		   // function: fprintf
		fprintf( filePtr, "%c", outChar );

		// return successful operation
		return true;
	   }
  
	// return failed operation
	return false;
   }

/*
Name: writeCharactersToFile
Process: writes multiple characters to file,
		 returns true if successful, false otherwise
Function input/parameters: number of characters to output (int),
						   character to output (char)
Function output/parameters: none
Function output/returned: operation success (bool)
Device input/file: none
Device output/file: multiple characters written to file
Dependencies: writeCharacterToFile
*/
bool writeCharactersToFile( int numChars, char outChar )
   {
	// check for number of characters remaining,
	if( numChars > 0 )
	   {
		// write character, check for success 
		   // function: writeChar
		if( writeCharacterToFile( outChar ) )
		   {
			// continue recursion, 
			// check for downstream success
			   // function: writeChars
			return writeCharactersToFile( numChars - 1, outChar );
		   }

		// quit recursion
		// return unsuccessful operation - write operation failed
		return false;
	   }

	// return successful operation - all characters have been written
	return true;
   }

/*
Name: writeStringToFile
Process: writes String value to file,
		 returns true if successful, false otherwise
Function input/parameters: double value to output (double),
						 number of digits to right of radix point
						 (precision) (int)
Function output/parameters: none
Function output/returned: operation success (bool)
Device input/file: none
Device output/file: String written to file
Dependencies: writeStringJustifiedToFile
*/
bool writeStringToFile( const char *outString )
   {
	// initialize variables, set block size to zero and justified to "LEFT"
	int blockSize = 0;
	char justified[] = "LEFT";
 
	// call to justified function
	   // function: writeStringJustifiedToFile
	return writeStringJustifiedToFile( outString, blockSize, justified );
   }
   

/*
Name: writeStringJustifiedToFile
Process: write string to file within specified block size
		 and with specified justification
Function input/parameters:
			   outVal - the string value to be output
			   blockSize - the width of the block within which
						   to print the integer value (int)
			   justify - "LEFT," "RIGHT," or "CENTER" justification 
						 in block (c-string)
Function output/parameters: None
Function output/returned: success of output operation (bool)
Function input/keyboard: None
Device output/file: string written to file as specified
Dependencies: strlen, strcmp, writeCharactersToFile, fprint
*/
bool writeStringJustifiedToFile( const char *outStr,
										int blockSize, const char *justify )
  {
     
   // initialize variables, set pre-, post- spaces to zero
   int preSpaces = 0, postSpaces = 0, strLength;

   // get file pointer
	  // function: accessFileOutputFilePointer
   FILE *filePtr = accessOutputFilePointer( GET_OUTPUT_FILE_PTR, 
													DUMMY_OUTPUT_FILE_PTR );

   if( filePtr != NULL )
	  {
	   // find length of string
		  // function: strlen
	   strLength = getStringLength( outStr );

	   // check justification for "LEFT"
		  // function: strcmp
	   if( compareString( justify, "LEFT" ) == STR_EQ )
		  {
		   // set post spaces for left justification
		   postSpaces = blockSize - strLength;
		  }

	   // otherwise, check justification for "RIGHT"
		  // function: strcmp
	   else if( compareString( justify, "RIGHT" ) == STR_EQ )
		  {
		   // set pre spaces for right justification
		   preSpaces = blockSize - strLength;
		  }

	   // Otherwise, assume "CENTER" justification
	   else
		  {
		   // set pre spaces for centered
		   preSpaces = blockSize / 2 - strLength / 2;

		   // set post spaces for centered
		   postSpaces = blockSize - strLength - preSpaces;
		  }

	   // print pre spaces, check for success
		  // function: writeCharactersToFile
	   writeCharactersToFile( preSpaces, SPACE );
		  
	   // print string
		  // function: fprintf
	   fprintf( filePtr, "%s", outStr );

	   // print post spaces
		  // function: printChars
	   writeCharactersToFile( postSpaces, SPACE );

	   // return successful operation
	   return true;
	  }

   // return failed operation
   return false;
  }
  
  